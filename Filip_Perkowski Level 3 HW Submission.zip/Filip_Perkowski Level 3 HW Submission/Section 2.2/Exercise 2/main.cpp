#include <iostream>
#include <sstream>
#include <cmath>
#include "Point.h"


int main() {
	
	double x;
	double y;

	
	//User Input asking for x and y coordinates; It's important to note that we can combine the cin into one so we can essentially do: std::cin >> x >> y;
	std::cout << "Please enter an x coordinate: ";
	std::cin >> x;

	std::cout << "Please enter a y coordinate: ";
	std::cin >> y;

	Point p1; //This create a Point object we called it p1; By default whenver we create a class object we intiate the default constructor so right now it's coordinates are: {0,0}
	Point p2;

	//Testing the deafult constructor
	std::cout << "Pre-Setting intiating the default constructor Point p1's x-coordinate is: " << p1.GetX() << " and y-coordinate is: " << p1.GetY() << std::endl;

	//Now using the setter function SetX() and SetY() to make m_x and m_y values of x and y instead of 0 and 0
	p1.SetX(x); //This sets Point objects P1 m_x value to the user input for the x coordinate
	p1.SetY(y); //This sets the P1's m_y value to the user input for the y-coordinate

	//Now testing the ToString() function
	std::cout << p1.ToString() << std::endl;

	//Finally, printing onto the console p1's x m_x and m_y throught the use of the Get() functions. This also double checks the correctness of the setter() functions
	std::cout << "After setting as per user input p1's x-coordinate is now: " << p1.GetX() << " and p1's y-coordinate is now: " << p1.GetY() << std::endl;
	

	//Extension of the 1st Testing file
	//Here we are testing our new DistanceOrigin() and Distance() Functions

	Point p1; //Here we create 2 Point objects p1 and p2; The default constructor gets initiated
	Point p2;

	p1.SetX(2); //Here we set our p1 so that it's: (2,2)
	p1.SetY(2); 

	p2.SetX(4); //Similar idea we set Point object p2 so that it's: (4,4)
	p2.SetY(4);

	//Now finding the distance between our Point p1 and the origin
	std::cout << "The distance between our Point p1 and the origin is: " << p1.DistanceOrigin() << std::endl;

	//Now finding the distance between 2 Point objects
	std::cout << "The distance between points p1 and p2 is: " << p1.Distance(p2) << std::endl;

	//Both functions output correctly
}








