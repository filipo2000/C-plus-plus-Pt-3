#pragma once
#include <iostream>
#include <sstream>
#include <string>

#ifndef  Point_h //Mechanism to avoid multiple inclusion of the header file
#define Point_h


// Objective -> This is our header file which contains all the variables/functions that each object of class Point will have to its disposal


class Point {

	private:
		//Our x and y coordinates which each Point object will have
		double m_x;
		double m_y;

	public:
		//Our constructors
		Point(); //Default Constructor 
		Point(double a, double b); //Constructor which takes in 2 double arguments
		~Point(); //Deconstructor

		//Our Getter Functions
		double GetX(); //Fetches x coordinate aka m_x
		double GetY(); //Fetches y coordinate aka m_y

		//Our Setter Functions
		void SetX(double a); //Asigns the value that parameter a hold to m_x
		void SetY(double b); //Assigns b to m_y 

		//String Function
		std::string ToString(); //Returns a string Description of Point object 

		//Our Distance functions
		double DistanceOrigin(); //This will calculate the distance from the point that intiaties this function to the origin
		double Distance(Point p); //This will return the distance from the Point provided via argument to the point which initiated this function via the . opeartor
};

#endif