
#include <iostream>
#include <sstream>
#include <cmath>
#include "Point.h"

//Objective -> This is our source file where will will define each entity within the Point class
//Members of the class can freely acess private members as private members are accesible within the class

//Again we acess these function on a given Point class object by doing: name of the Point class object.name of the function(arguemnts if the function has parameter/s)

//Starting by defining the constructors
Point::Point() { //Our Default Constructor
	m_x = 0;
	m_y = 0;
}

Point::Point(double a, double b) {
	m_x = a;
	m_y = b;
}


Point::~Point() { //Our Deconstructor

}


//Now defining our Getter Functions
double Point::GetX() {
	return m_x;
}

double Point::GetY() {
	return m_y;
}


//Defining our setter Functions
void Point::SetX(double a) {
	m_x = a;
}


void Point::SetY(double b) {
	m_y = b;
}


std::string Point::ToString() {
	//These are our 2 stringstream objects which will hold our m_x and m_y
	std::stringstream first;
	std::stringstream second;

	//Stringstream will hold m_x and m_y respectively in their buffer
	first << m_x;
	second << m_y;

	std::string resi = "Point {" + first.str() + "," + second.str() + "}";
	return resi;
}

//This function calculates the distance from the point object that initiates it with the . operator to the origin
double Point::DistanceOrigin() { //Remember private members are accesible within the class aka function within the class can acess private data members
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));  //Returns the value of c in the Pythagorean Theorem which is what we want
}

double Point::Distance(Point p) { //P.m_x reffers to the x coordinate value of the Point object that was passed through object when calling the function. m_x reffers to the x coordinate of the point object that uses the . operator to intiaite the function call
	return sqrt(pow(m_x - p.m_x,2) + pow(m_x - p.m_x,2)); //It doesn't matter which number we are subtracting by since we are squaring it; Returns the value of c in the Pythangorean Theorem 
}