#include <iostream>
#include <sstream>
#include "Point.h"

//C++ libraries etc. should be include in <> notation. Self made files etc. should be denoted in "" notation

//This is our test program where we have our main function and we will test our Point Class
//Remember we can't just acess a classes private data member by just using the . operator. The . operator is only valid for public members

int main() {

	double x; //This variable will hold the value for the x coordinate
	double y; //This variable will hold the value for the y coordinate


	//User Input asking for x and y coordinates; It's important to note that we can combine the cin into one so we can essentially do: std::cin >> x >> y;
	std::cout << "Please enter an x coordinate: ";
	std::cin >> x;

	std::cout << "Please enter a y coordinate: ";
	std::cin >> y;

	Point p1; //This create a Point object we called it p1; By default whenver we create a class object we intiate the default constructor so right now it's coordinates are: {0,0}

	//Testing the deafult constructor
	std::cout << "Pre-Setting intiating the default constructor p1 is: " << p1.ToString() << std::endl;

	//Now using the setter function SetX() and SetY() to make m_x and m_y values of x and y instead of 0 and 0
	p1.SetX(x); //This sets Point objects P1 m_x value to the user input for the x coordinate
	p1.SetY(y); //This sets the P1's m_y value to the user input for the y-coordinate

	//Now testing the ToString() function
	std::cout << "After setting we have: " << p1.ToString() << std::endl;

	//Finally, printing onto the console p1's x m_x and m_y throught the use of the Get() functions. This also double checks the correctness of the setter() functions
	std::cout << "Confirmation - After setting as per user input p1's x-coordinate is now: " << p1.GetX() << " and p1's y-coordinate is now: " << p1.GetY() << std::endl;


}

