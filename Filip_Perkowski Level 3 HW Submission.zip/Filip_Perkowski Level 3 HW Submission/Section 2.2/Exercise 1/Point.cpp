#include <iostream>
#include <sstream>
#include "Point.h"

//Objective -> This is our source file where will will define each entity within the Point class
//Members of the class can freely acess private members as private members are accesible within the class

//Again we acess these function on a given Point class object by doing: name of the Point class object.name of the function(arguemnts if the function has parameter/s)

//Starting by defining the constructors
Point::Point() { //Default Constructor
	m_x = 0;
	m_y = 0;
}

Point::Point(double a, double b) { //Constructor which takes in 2 double arguments
	m_x = a;
	m_y = b;
}


Point::~Point() { //Deconstructor

}


//Now defining our Getter Functions
double Point::GetX() { //Gets/Returns the x coordinates aka m_x
	return m_x;
}

double Point::GetY() { //Gets/Returns the y coordinate aka m_y
	return m_y;
}


//Defining our setter Functions
void Point::SetX(double a) { //Set the value of the x coordinate to the value passed to the parameter when calling SetX()
	m_x = a;
}


void Point::SetY(double b) { //Sets the value of the y coordinate to the value passed to the parameter when calling SetY()
	m_y = b;
}


std::string Point::ToString() { //This functions returns a string description of the Point class object that acesses this ToString() function via the . operator
	//These are our 2 stringstream objects which will hold our m_x and m_y
	std::stringstream first;
	std::stringstream second;

	//Stringstream will hold m_x and m_y respectively in their buffer
	first << m_x;
	second << m_y;

	std::string resi = "Point (" + first.str() + "," + second.str() + ")";
	return resi;
}


