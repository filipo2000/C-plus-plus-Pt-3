#pragma once

#ifndef Point_h //Our mechanism to prohibit multiple decleration/inclusion of the header file
#define Point_h

#include <iostream>


//Objective -> This is our Point Class header file; Here we provide all the components that will be within the Point class
//We call these function by using the . operator; Point class object . name of function/variable etc. This will make it so that the function/variable will get initatiated on the Point Class object
//We can freely acess public entities of the class using the . opeartor. However, we can't do this with private members. Since a private member is only truly defined within the class, we can include the private member as a return value in a public function and return that public function


class Point {

	private:
	//Both of these are our x and y coordinates; Each Point object will have it's own set of m_x, m_y, GetX() function etc.
		double m_x;
		double m_y; 

	public:
		//Our set of constructors
		Point(); //This is our default constructor(simply the name of the class) which will provide intitial values to m_x and m_y whenever we create an object of Point Class
		Point(double a, double b); //This is our constructor which takes in 2 double arguments these values become the m_x and m_y value for the Point class object that decleraed when this consrtuctor gets initiated
		~Point(); //This is our destructor which will run whenever the program is terminated

		//Our Getter Functions
		double GetX(); //This function will return the x coordinate(aka m_x) of the Point object that it is called upon
		double GetY(); //Same idea as GetX() but will return the y coordinate(aka m_y)

		//Our setter functions
		void SetX(double a); //This function will set the x_cordinate of the Point object to the value of a(the argument value passed in to the parameter when the function is called). This function shouldn't return anything but just change the x_cordinate value of the Point object that calls it
		void SetY(double b); //Similar idea to SetX() except that here the y_cordinate is changed instead of the x_cordinate

		//Function which will describe the Point Object
		std::string ToString(); //This function will take in an ostream object(which will hold the description of the Point object in it's buffer). We should ideally convert this argument into a string via .str() and return this version
};

#endif