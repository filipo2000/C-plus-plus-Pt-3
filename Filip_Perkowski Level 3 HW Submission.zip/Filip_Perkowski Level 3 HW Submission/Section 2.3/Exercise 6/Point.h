#pragma once
//All the relevant header files, source files etc. should be within the project. This way they are accesible when needed

#ifndef Point_h
#define Point_h

#include <iostream>
#include <sstream>
#include <cmath>
#include <string>

//Objective -> In this file we include all the important components in the Point class

class Point {
	private:
		double m_x;
		double m_y;
	public:
		//Our set of Constructors
		Point();
		Point(double a, double b);
		Point(const Point& a);
		~Point();

		//Our Get() Functions
		const double X() const;
		const double Y() const;

		//Our Set() Functions
		void X(const double& a);
		void Y(const double& b);

		//Our ToString() Functions
		std::string ToString() const;

		//Our Distance() Functions
		double Distance() const;
		double Distance(const Point& p) const;
};

#endif