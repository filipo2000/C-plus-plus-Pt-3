#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Circle.h" 

//Objective -> Here we will test the constructs/properties of the Circle class. We will do this by creating objects of type Circle class and fetching functions within the Circle class via the . operator

int main() {

	Circle c1; //This creates a Circle object. Furthermore, we initiate the default constructor within the Circle class to create/declare our c1 Circle class object
	//Testing the Default Constructor and CentrePoint() + Radius() functions
	std::cout << c1.CentrePoint().X() << c1.CentrePoint().Y() << std::endl; //This should print onto the console the X and Y coordinates of the Centre Point of our Circle class object c1; It should be {0,0}
	std::cout << c1.Radius().P1().X() << c1.Radius().P1().Y() << c1.Radius().P2().X() << c1.Radius().P2().Y() << std::endl; //Alternatively we could've created a const Line object by just calling the Radius function created a Point object by calling the Line object.P1() and created a double object by calling this Point object.X() etc.
	 //The default constructor and CentrePoint() and Radius() functions work great

	//Here we create a collection of Point and Line objects 
	Point p1(10,20);
	Point p2(5,20);
	Line l1(p1, p2);
	Line l2;

	Circle c2(l1,p1); //This creates a Circle object called c2 and calls the constructor which contains a Line and Point object parameter
	std::cout << c2.ToString() << std::endl; //The ToString() Function works great

	//Now testing the Set() Functions
	c2.CentrePoint(p2); //This should now set Circle class object c1's centre point to p2. It was previously p1
	//Verifying The Above
	std::cout << "Circle object c2's centre point is now: Point (" << c2.CentrePoint().X() << "," << c2.CentrePoint().Y() << ")" << std::endl;

	//c2.Radius(l2); //Line l2 is a Line object declared by initiating the deafault constructor. Hence Point should be {0,0}
	std::cout << "Circle object's c2 radius now consists of: Point (" << c2.Radius().P1().X() << "," << c2.Radius().P1().Y() << ")" << std::endl;

	//Testing the Measurement Functions
	std::cout << "Circle c2's area is: " << c2.Area() << std::endl;
	std::cout << "Circle c2's circumfrence is: " << c2.Circumfrence() << std::endl;
	std::cout << "Circle c2's diameter is: " << c2.Diameter() << std::endl;

	//Everything works as it should
}