#define _USE_MATH_DEFINES 
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include "Circle.h"

//By doing the above #define directive and cmath header file we should be able to use the PI value 3.14 freely

//Objective -> This is the file where we define all the properties within the Circle class


Circle::Circle() {
	Point(); //Our Circle class default constructor calls the Point() and Line() class default constructors
	Line();
}

Circle::Circle(Line a, Point b) {
	m_radius = a; //This contstructor take a Line and Point argument as shown by the parameter type. These arguments are used to initialize the properties of a Line class object. 
	c_point = b;
}

Circle::Circle(const Circle& c) {
	m_radius = c.m_radius; //Here we pass by reference since our parameter is a reference. We pass in a Line class object and so the Line class object that we will create by initiating this constructor will have the same property values: c_point and m_radius as the Line class object passed as the argument
	c_point = c.c_point;
}

Circle::~Circle() { //This is our destructor. Our destructor gets activated whenever an object of type Circle class object is discared/terminated/destroyed
	//std::cout << "This is the destructor!!" << std::endl;
}

//Our Get() Functions; These set of functions return the properties of a give Circle class object: m_radius and c_point respectively
const Line Circle::Radius(){
	return m_radius;
}

const Point Circle::CentrePoint(){ 
	return c_point;
}

//Our Set() Functions; These set of functions set the properties of a given Circle class object. m_radius and c_point respectively
void Circle::Radius(const Line& l) { 
	m_radius = l;
}

void Circle::CentrePoint(const Point& p) {
	c_point = p;
}

//Our Functions which return measurements of a given Circle object; This function returns the Area of a given Circle class object we initiate this function in the form [name of the Circle class object] . Area() -> This command hold the double value which is the return type of this function
double Circle::Area() const {
	return (M_PI * pow(m_radius.Length(), 2)); // Pi * (Radius^2)
}

double Circle::Circumfrence() const { //This function returns the circumfrence of a given Circle object
	return 2 * M_PI * m_radius.Length(); //m_radius.Length() equals the length of the radius of the object of Circle class type; 2 * Pi * Radius
}

double Circle::Diameter() const { //This function returns the diameter of a given circle object; Radius * 2
	return m_radius.Length() * 2;
}

//Our ToString() Function
//Fix the problem here
std::string Circle::ToString() const { //Our ToString Object returns a string which describle our Circle class object
	std::stringstream a, b;
	a << "Line with Points: (" << m_radius.P1().X() <<  ","  << m_radius.P1().Y() << ") and" << " (" << m_radius.P2().X() << "," << m_radius.P2().Y() << ")"; //Looks perfect now
	b << "Center Point (" << c_point.X() << "," << c_point.Y() << ")";
	std::string resi = "Our Circle objects has a " + a.str() + " and a " + b.str();
	return resi;

}




















