#pragma once

#ifndef Circle_h
#define Circle_h

#include <iostream>
#include <sstream>
#include <cmath>
#include <string>
#include "Line.h" //We include the Line header file so now we can freely use Line objects here without it being undefined. Our Line header file include the Point header file therefore we can also use Point objects here freely as well
//#include "Point.h" -> This isni't necessary although you can put it

//Objective -> This is our Circle class header file. In this file we include all the properties within the Circle class

class Circle {
	private:
		Line m_radius;
		Point c_point;
	public:
		//Declaring our set of constructors and deconstructor
		Circle();
		Circle(Line a, Point b);
		Circle(const Circle& c);
		~Circle();
		
		//Declaring our Get() Functions; As you can see we have overloaded functions
		const Point CentrePoint();
		const Line Radius();

		//Declaring our Set() Functions
		void CentrePoint(const Point& p);
		void Radius(const Line& l);

		//ToString()
		std::string ToString() const;

		//Functions which return measurements of a Circle class object
		double Diameter() const; //Since these functions don't change the values of m_radius and/or c_point for any Circle class object that uses the . operator on these functions, we should add the const keyword as done so
		double Area() const;
		double Circumfrence() const;
		


};

#endif



































