#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Point.h"

//Objective -> In this file we define all the components within the Point Class

//Starting by defining our constructors and deconstructor
Point::Point() {
	m_x = 0;
	m_y = 0;
}

Point::Point(double y, double z) {
	m_x = y;
	m_y = z;
}

Point::Point(const Point& f) { //The key was to make this parameter const
	m_x = f.m_x;
	m_y = f.m_y;
		
}

Point::~Point() {
	//std::cout << "This is the destructor!!" << std::endl;
}

//Defining our Get() Functions
const double Point::X() const {
	return m_x;
}

const double Point::Y() const {
	return m_y;
}

//Defining our Set() Functions
void Point::X(const double& a) {
	m_x = a;
}

void Point::Y(const double& b) {
	m_y = b;
}

//Defining our ToString() Function
std::string Point::ToString() const {
	std::stringstream a, b;
	a << m_x; //Alternatively we could have one stringstream object which holds everything in its buffer and return it .str() in string form 
	b << m_y;
	std::string resi = "Point {" + a.str() + "," + b.str() + "}";
	return resi;
}

//Defining our Distance() Functions
double Point::Distance() const {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(const Point& p) const {
	return sqrt(pow(m_x - p.m_x, 2) + pow(m_y - p.m_y, 2));
}