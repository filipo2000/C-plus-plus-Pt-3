#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Line.h"

//Objective -> This is our Line source file which essentially defined all the properties within our Line class

//Starting by defining our constructors and deconstructor
Line::Line() {
	Point(); //This calls the default constructor from the Point class; Remember that we can't fetch the m_x and m_y properties of the Point class as they're private and therefore only accesible by functions within the point class. Our only choice is to call the default Point constructor which sets these value to 0
}

Line::Line(Point p1, Point p2) {
	start = p1;
	end = p2;
}

Line::Line(const Line& p) {
	start = p.start;
	end = p.end;
}

Line::~Line() {
	//std::cout << "This is the destructor!!" << std::endl
}


//Defining our Get() Functions
Point Line::P1() const { //Now start and end which are Point class object and constitute a Line class object can be freely used here despite the fact that start and end are private members. The reason is because P1() and P2() are functions within the Line class
	return start; 
}

Point Line::P2() const {
	return end;
}


//Our Set() Functions
void Line::P1(const Line& l1) {
	start = l1.start;
}

void Line::P2(const Line& l2) {
	end = l2.end;
}


//Our ToString() Function
std::string Line::ToString() const {
	std::stringstream a, b;
	a << "Point { " << start.X() << "," << start.Y();
	b << "Point { " << end.X() << "," << end.Y();
	std::string resi = "Our line includes: " + a.str() + "and" + b.str();
	return resi;
}

//Our Length() Function
double Line::Length() const {
	return start.Distance(end); //We could've also wrote end.Distance(start) and it would've outputed the same result
}