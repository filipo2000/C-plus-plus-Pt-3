#pragma once

#ifndef Line_h
#define Line_h

#include <iostream>
#include <sstream>
#include <string>
#include "Point.h" //This is key; Otherwise Point class objects won't be defined in this file

//Objective -> In this file we include all the important features of the Line class

class Line {
	private:
		Point start;
		Point end;
	public:
		//Our Constructors and Deconstructor
		Line();
		Line(Point p1, Point p2);
		Line(const Line& l1); //The copy constructors parameter should be const this is because we aren't using the reference to change the value of the argument. What we are doing is using the reference as an alias for the argument for the newly created object to have the same property values as the object provided via argument has
		~Line();
		
		//Our Get() Functions
		Point P1() const; //This will return the start point of a line object
		Point P2() const; //This will return the end point of a line object

		//Our Set() Functions
		void P1(const Line& l1); //Now need for pass by value and copying
		void P2(const Line& l2);

		//ToString() Function
		std::string ToString() const; //In the body of this function we won't be changing the value of start and/or end of the Line class object that uses the . operator on this function. Hence, we should use the const keyword here
		
		//Length() Function
		double Length() const; //This function returns the difference in value between 2 Line class objects



};

#endif