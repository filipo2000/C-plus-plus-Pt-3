#pragma once
#include <iostream>
#include <sstream>
#include <string>

#ifndef Point_h
#define Point_h

//Objective -> This is our header file which contains all the properties of the Point Class

//IMPORTANT: Double check if the spacing is correct

class Point {
	private:
		double m_x;
		double m_y;
	
	public:
		
		//Our Set Of Constructors
		Point(); //Our default constructor
		Point(double x, double y); //Our constructor which takes 2 double arguments
		Point(Point& p); //Our copy constructor
		~Point(); //Our Destructor

		//Our Get Functions()
		double X(); //This function returns our x cordinate
		double Y(); //This function returns our y cordinte

		//Our Set Functions()
		void X(double a); //This function assigns the x coordinate of our point to the value of the argument passed to the parameter when calling the function
		void Y(double b); //This function assigns the y coordinate of our point to the value of the argument passed to the parameter when calling the function

		//To String() Function which describes the string
		std::string ToString();

		//Distance() Functions
		double Distance(); //This function will return the distance between the point class object type which calls this function via the . operator and the origin
		double Distance(const Point& p); //This function will return the distance between the point class object type which calls this function via the . operator and the origin and the point class object that's provided via argument when calling the function

		//When it comes to overloaded functions. Whenever we call a function, the compiler knows which function we are reffering to based on the arguments we provide it.
};

#endif