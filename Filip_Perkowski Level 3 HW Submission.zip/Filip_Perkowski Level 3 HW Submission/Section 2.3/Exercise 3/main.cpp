#include <iostream>
#include <sstream>
#include <cmath>
#include <string>
#include "Point.h"

//Objective -> This is our main .cpp file due to the fact that we have our main() function here. In this file we test the validity of all the components of the Point class

int main() {

	Point p1; //Here we create a Point class object by initiating the default constructor
	Point p2(12, 20); //Here we create a Point class object by initatig the constructor that contains 2 double parameters

	double a = p1.Distance(); //Now given that here we call the Distance() function providing no parameter. Despite the fact that we have overloaded functions, the compiler knows that we are reffering to the Distance function that determines the distance between Point p1 and the origin
	//The function returns a double value hence we should store it in a double variable

	//Outputing; The result should be 0 as the default constructor assigns 0 to the Point classes object x and y coordinates
	std::cout << "The distance between Point p1 and the origin is: " << a << std::endl;

	p1.X(2); //This set's Point p1's X coordinate to 2
	p1.Y(4); //This sets Point p1's Y coordinate to 4

	//Printing our the distance between Point p1 which is now: {2,4} and Point p2 which is: {12,20}
	std::cout << "Now the distance between Point p1 and p2 is: " << p1.Distance(p2) << std::endl; //We could've wrote is as p2.Distance(p1) it doesn't matter in this case as we would arrive with the same result

	//We can verify that Point p1 is actually: {2,4} by using the Get Functions X() and Y() one by one our use the ToString() function
	std::cout << p1.ToString(); 


}