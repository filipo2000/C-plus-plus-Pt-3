#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Point.h"

//Objective -> This file defines the properties within the Point Class

//Starting by defining our constructor
Point::Point() {
	m_x = 0;
	m_y = 0;
}

Point::Point(double a, double b) {
	m_x = a;
	m_y = b;
}

Point::Point(Point& a) {
	m_x = a.m_x;
	m_y = a.m_y;
}

Point::~Point() { //Our Destructor
	//std::cout << "Our Destructor" << std::endl;
}


//Defining our Get() Functions; Our functions are now overloaded(more than 1 function with the same name. However, as long as the parameter combination is unique and we input the appropriate argument types when calling the specific function, the compiler will know which function we are reffering to
double Point::X() {
	return m_x;
}

double Point::Y() {
	return m_y;
}

//Defining our Set() Functions
void Point::X(double a) {
	m_x = a;
}

void Point::Y(double b) {
	m_y = b;
}

//ToString() Functions
std::string Point::ToString() {
	std::stringstream a, b; //Alternative to defining stringstream objects
	a << m_x; b << m_y; //Alternative; If this doesn't work then put the b << m_y on the next line
	std::string resi = "Point {" + a.str() + "," + b.str() + "}";
	return resi;

}

//Distance() Functions
double Point::Distance() {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(const Point& p) {
	return sqrt(pow(m_x - p.m_x,2) + pow(m_y - p.m_y, 2));
}