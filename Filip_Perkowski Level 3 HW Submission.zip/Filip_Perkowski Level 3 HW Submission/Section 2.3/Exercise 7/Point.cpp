#include <iostream>
#include <sstream>
#include <cmath>
#include <string>
#include "Point.h"

//Objective -> This is our .cpp file. In this file we define all the properties(functions etc.) within the Point class

//Starting by defining our Point Class constructors
Point::Point() {
	m_x = 0;
	m_y = 0;
}

Point::Point(double a, double b) {
	m_x = a;
	m_y = b;
}


Point::Point(const Point& c) {
	m_x = c.m_x;
	m_y = c.m_y;
}

Point::~Point() {
	std::cout << "The Deconstructor!!" << std::endl;
}


//ToString() Function
std::string Point::ToString() const {
	std::stringstream a, b;
	a << "Point {" << m_x << "," << m_y << "}";
	return a.str();
}

//Our Distance() Functions
double Point::Distance() const {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(const Point& p) const {
	return sqrt(pow(m_x - p.m_x, 2) + pow(m_y - p.m_y, 2));
}
























