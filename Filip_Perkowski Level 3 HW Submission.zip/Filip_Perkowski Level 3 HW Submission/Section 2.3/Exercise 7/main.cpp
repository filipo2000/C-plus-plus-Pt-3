#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Point.h"

//Objective -> This is our main function file. In this file we will test all the properties within the Point class. If they work well etc.

int main() {

	//Testing the X() and Y() get functions
	Point p1(10, 15);
	std::cout << p1.X() << "," << p1.Y() << std::endl;

	p1.X(13); //Using the set X() and Y() functions to change the m_x and m_y value of the underlying p1 Point class function
	p1.Y(20);
	std::cout << p1.X() << "," << p1.Y() << std::endl; //Checking if the set() X() and Y() functions work; Works perfectly


}