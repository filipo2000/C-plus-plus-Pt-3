#pragma once

#ifndef Point_h
#define Point_h

#include <iostream>
#include <sstream>
#include <string>
#include <cmath>

//Objective -> This is our Point Class header file. In this file we declare all the properties within the Point Class

class Point {
	private:
		double m_x;
		double m_y;
	public:
		//Our set of constructors and deconstructors
		Point();
		Point(double a, double b);
		Point(const Point& p); //IMPORTANT: ITS IMPORTANT THE PARAMETER IS CONST. MAKE SURE THIS IS THE CASE THROUGHOUT THE LEVEL
		~Point();

	//Our Get() Functions
		double X() const;
		double Y() const;

	//Our Set() Functions; These are our default inline functions(definitions are inside the class decleration)
		void X(const double& a) {
			m_x = a;
		};
		void Y(const double& b) {
			m_y = b;
		};

	//ToString() Function
		std::string ToString() const;

	//Distance() Functions
		double Distance() const;
		double Distance(const Point& p) const; //IMPORTANT: SAME IDEA HERE THE PARAMETER IS CONST. MAKE SURE THIS IS THE CASE THROUGHOUT ALL THE EXERCISES


};

//Implenting the Normal Inline Functions(Outside the class decleration)
inline double Point::X() const {
	return m_x;
}

inline double Point::Y() const {
	return m_y;
}

#endif