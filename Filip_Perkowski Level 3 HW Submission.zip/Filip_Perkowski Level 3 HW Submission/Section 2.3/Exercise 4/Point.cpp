#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Point.h"

//Objective -> In this source file we are defining the properties that are within the Point Class

//Starting by defining the constructors and deconstructor
Point::Point() {
	m_x = 0;
	m_y = 0;
}

Point::Point(double a, double b) {
	m_x = a;
	m_y = b;
}

Point::Point(Point& p) {
	m_x = p.m_x;
	m_y = p.m_y;
}

Point::~Point() {
	//std::cout << "This is the Deconstructor" << std::endl;
}

//Defining the Set() Functions
double Point::X() const {
	return m_x;
}

double Point::Y() const {
	return m_y;
}

//Defining the Set() functions
void Point::X(double s) {
	m_x = s;
}

void Point::Y(double z) {
	m_y = z;
}


//ToString() Functions
std::string Point::ToString() const {
	std::stringstream a;
	std::stringstream b;
	a << m_x;
	b << m_y;
	std::string resi = "Point { " + a.str() + "," + b.str() + "}";
	return resi;
}

//Defining our Distance() functions
double Point::Distance() const {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(const Point& p) const {
	return sqrt(pow(m_x - p.m_x, 2) + pow(m_y - p.m_y, 2));
}