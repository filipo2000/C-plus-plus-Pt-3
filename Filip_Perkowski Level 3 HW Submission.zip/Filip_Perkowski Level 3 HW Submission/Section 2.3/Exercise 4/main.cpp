#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Point.h"

//Objective -> In this source file we have our main function and we test the properties of the Point class to see if everything works properly

//The front const may not be necessary

//The key for the const Point object to work was the put the post const keyword for the Getter Functions()
//const int X() const; In this decleration the const in front denotes that the return type is const int; The const at the end denotes that const objects can call the function. Aka this reasures the fact that the functions body does not change m_x or m_y 

int main() {

	//3 Point objects defined. Each one intiaties a different constructor type
	Point p1;
	Point p2(30, 40);
	Point p3(p2);

	//Here we create a const Point class object
	const Point cp(1.5, 3.9); //Any function that doesn't change the components of the object in this case: m_x and m_y should work fine
	//cp.X(10.3); //Here we try to change cp's x coordinate value to 10. Of course this shouldn't be able to work as cp is a const object
	//As expected we get a compiler error for the above line; The above line will give an error regardless as we are trying to change the m_x value of Point class object cp. Since cp is a const object this can't be done

	//Now doing:
	std::cout << cp.X() << std::endl; //We get a compiler error here as well; This is because the compiler doesn't know whether or not this function changes the values of m_x or m_y or both. 



}