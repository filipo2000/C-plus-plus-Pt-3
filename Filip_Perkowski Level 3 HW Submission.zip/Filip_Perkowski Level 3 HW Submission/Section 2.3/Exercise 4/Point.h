#pragma once
#include <iostream>
#include <sstream>
#include <string>

#ifndef Point_h
#define Point_h

//If functions don't change the properties of a class object. In the case of a Point class object the m_x and m_y values, then it's best to mark these functions const. It's good programming practice and shows that you understand the idea of const in a class setting

//IMPORTANT: MAKE SURE THE SPACING/TABS ARE CORRECTLY INPUTTED IN THIS PROGRAM AND THROUGHOUT THE WHOLE LEVEL

//Objective -> This header file comprosies of all the entities that are within the Point Class

class Point {
	private:
		double m_x;
		double m_y;
	public:
		//Our set of constructors
		Point();
		Point(double x, double y);
		Point(Point& p);
		~Point();

		//Our Get() Functions; We now make these functions const functions
		double X() const; //We should mark these as const function given the fact that they don't change m_x or m_y
		double Y() const;

		//Our Set() Functions
		void X(double a);
		void Y(double b);

		//ToString() Function; We now make this function a const function
		std::string ToString() const; //This function wouldn't change m_x and m_y if we were to call it using a Point class object and the . operator hence we should make it const. This is good programming practice

		//Distance() Functions; We now make out Distance() functions const function since they don't change the values of m_x and/or m_y within their body
		double Distance() const; //Same idea as for the ToString() and Getter Functions
		double Distance(const Point& p) const; //If our parameter is a non-reference like so then we have a copy by value when we decide to call this function. If the parameter is a reference then we have a call by reference

};

#endif