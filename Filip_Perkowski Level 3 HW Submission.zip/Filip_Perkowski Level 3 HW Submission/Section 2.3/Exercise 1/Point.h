#pragma once
#include <string>
#include <sstream>

#ifndef Point_h
#define Point_h

//Objective -> This is our header file in which we will define the contents of our Point Class

class Point {
	private:
		double m_x; //Components of a Point class object
		double m_y;
	public:
		//Starting with our set of construtors
		Point(); //Default constructor; This gets initiates whenever we create a Point object and do not provide it with any parameters
		Point(Point& a); //This is our Copy Constructor; Argument is a point and essentially the Point we create via this constructor gets passed the x and y coordinate values from the Point object provided through argument 
		Point(double a, double b); //r; This constructor takes in x and y values. This constructor gets intiated whenever we crate a Point object and provide it with arguments. These arguments would become the x and y coordinate values for that object
		~Point(); //This is our destructor

		//Now with our Get() Function; These functions fetch the x and y coordinates respectively
		double GetX();
		double GetY();

		//Set() Functions; These functions set the value of the x and y coordinates(m_x and m_y) based on the values provided via argument
		void SetX(double y);
		void SetY(double z);

		//ToString() function; This function returns a string description of the Point class object
		std::string ToString();

		//Distance() Functions; 
		double DistanceOrigin(); //This function returns the distance between a Point class object and the origin
		double Distance(Point p); //This function returns the distance between 2 Point class objects

};

#endif