
#include <iostream>
#include <sstream>
#include <cmath>
#include "Point.h"

//Objective -> This is our .cpp file which we have our main function and test the contents of our Point class

//A Point Object can be redefiend. However you can't redefine with the use of a constructor. Constructors are only used whenver objects of class type are first introduced in the program

int main() {

	//Experimenting the frequency of the Default Constructor and the Deconstructor
	Point p1; //This initiates the default constructor
	Point p2(10, 20); //This initiates the constructor which takes the 2 double arguments

	
	
	//Calculating the distance between points: p1 and p2
	std::cout << p1.Distance(p2) << std::endl; //Comment this line out and we will see 2 occurences of the Deconstructor and 1 occurence of the Default constructor

	//The default constructor gets ran one time and the destructor gets ran 3 times. This makes sense as theres only 1 Point object that we create using the Point a; syntax hence initiating the default constructor
	//Furthermore we have 2 Point objects in our program hence when the program terminates 2 Point objects will get terminated hence the Destructor gets called 2 times + 1 more time when the distance between the Points is calculated
	//As a result the frequency is not the same

	//User input
	double x;
	double y;
	std::cout << "Please enter a x value: " << std::endl;
	std::cin >> x;
	std::cout << "Please enter a y value: " << std::endl;
	std::cin >> y;
	
	//Implementing the Copy Constructor
	Point p3 (x, y); //Creating a Point object p3 from user input;
	Point p4(p3); //Using the Copy constructor; Now Point p4's x and y coordinates should be 20,30. We can confirm this using the Get() functions of the ToString() function
	std::cout << p4.ToString() << std::endl;

}

