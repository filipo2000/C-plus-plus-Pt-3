#include <iostream>
#include <string>
#include <sstream>
#include <cmath>
#include "Point.h"

//Objective -> This is our .cpp file. Here we define all the properties/components of the Point Class

Point::Point() { //We initiate the default constructor by decleraing a Point object in memory like so -> Point p1;
	m_x = 0;
	m_y = 0;
	std::cout << "This is the Default Constructor!!" << std::endl;
}


Point::Point(double a, double b) { //This constructor gets intiaited when we declare a Point object like -> Point c(10,12);
	m_x = a;
	m_y = b;
}


Point::Point(Point& c) { //This constructor runs we we create a Point object in memory like -> Point g(Point h); Or Point k(d) assuming d is a Point object already defined in the program
	m_x = c.m_x;
	m_y = c.m_y;
	std::cout << "This is the Copy Constructor" << std::endl;
}


Point::~Point() { //This gets initiated once the program terminates more specifically the Point objects gets destroyed
	std::cout << "This is the Destructor!!" << std::endl;

}


double Point::GetX() {  //These function are called via the . operator. [ Name of Point object -> . operator -> name of the function that we'd like to acess(must be a public member of the class) ]
	return m_x;
}

double Point::GetY() {
	return m_y;
}


void Point::SetX(double y) {
	m_x = y;
}

void Point::SetY(double z) {
	m_y = z;
}

std::string Point::ToString() {
	std::stringstream a;
	std::stringstream b;
	a << m_x;
	b << m_y;
	std::string resi = "Point (" + a.str() + "," + b.str() + ")";
	return resi;
}


double Point::DistanceOrigin() {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(Point p1) {
	return sqrt(pow(m_x - p1.m_x, 2) + pow(m_y - p1.m_y, 2));
}
