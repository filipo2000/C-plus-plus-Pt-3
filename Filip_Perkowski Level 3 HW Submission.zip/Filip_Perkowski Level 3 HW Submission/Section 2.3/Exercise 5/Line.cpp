#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Line.h"

//Objective -> This is the file where all the properties of the Line class are defined

//Starting by defining our constructors and deconstructor
Line::Line(){
	//start = 0; //We can't set a Point object to 0 it doesn't make sense we need to set it's properties equal to 0 aka m_x and m_y respectively
	Point(); //We call the default constructor from the Point Class
	//Alternatively we could've made m_x and m_y public and fetch those properties from Point class objects start and end
}

Line::Line(Point a, Point b) {
	start = a;
	end = b;
}

Line::Line(const Line& p) {
	start = p.start;
	end = p.end;
}

Line::~Line() {
	//std::cout << "This is the destructor" << std::endl;
}

//Our Get() Functions Defined; These functions return the start and end Point class objects respectively. These are the 2 components of a Line class object
Point Line::P1() const{
	return start; //For this to be a proper const function
}

Point Line::P2() const{
	return end;
}


//Our Set() Functions Defined; These function change the value of our start and end Point class objects which make up our Line class object
void Line::P1(const Point& p) {
	start = p;
}

void Line::P2(const Point& s) {
	end = s;
}

//Our ToString() Function
std::string Line::ToString() const {
	std::stringstream a, b;
	a << "Point (" << start.X() << "," << start.Y() << ")"; //This is the contents thats within a's buffer; a is a stringstream object
	b << "Point (" << end.X() << "," << end.Y() << ")";
	std::string resi = "Our line object includes: " + a.str() + " and " + b.str();
	return resi;

}

//Length() Function
double Line::Length() const {
	return start.Distance(end); //This returns the distance between the 2 points aka this is the equal to the length of the line
}
