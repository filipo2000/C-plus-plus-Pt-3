#pragma once

#ifndef Line_h
#define Line_h

#include <iostream>
#include <sstream>
#include <string>
#include "Point.h"

//Objective -> This is our header file which contains all the properties of the Line Class. So our Line header file should include the Point header file our Line.cpp file should contain the Line header file aka this file and main.cpp which will test the components of the Line class should include Line.h aka this file
//Based on the fact that the Line class contains Point class objects we should include the Point.h header file


class Line { //Our Line class object's components are 2 Point Class objects- start and end
	private:
		Point start;
		Point end;
	public:
		//This is our Constructor set + Deconstructor
		Line();
		Line(Point a, Point b); //If we make this constructor's parameters regular objects then we will encounter pass by value. If we make the parameters references then we will have pass by reference
		Line(const Line& p); //This is our Copy constructor; Why does the parameter of a copy constructor have to be a reference. Why can't there be a pass by value for the copy constructor
		~Line();

		//Get() Functions
		Point P1() const;
		Point P2() const;

		//Set() Functions
		void P1(const Point& p1);
		void P2(const Point& p2);

		//ToString() Function; This function will return the description of the Line class object
		std::string ToString() const;
			
		//Length() Function; This function will return the Length of the Line class object that uses the . operator on this Length() Function as this given point in time. Aka this calculates the distance between Points start and end of a given Line object
		//We can use the sqrt and pow functions or just use the Distance() function from the Point class since we will be operating with Point objects
		double Length() const;


};

#endif