
#include <iostream>
#include <sstream>
#include <cmath>
#include <string>
#include "Point.h"

//Objective -> This is the file in which the properties of the Point class are defined

//Our Constructors and Deconstructor Defined
Point::Point() { //Default Constructor
	m_x = 0;
	m_y = 0;
}

Point::Point(double a, double b) { //Constructor which takes in 2 double arugments. Contains 2 double parameters; Regerences are preffered as there's no need for copying. In addition, reference should be of const type to indicate that the reference is an alias for a const argument
	m_x = a;
	m_y = b;
}

Point::Point(const Point& a) { //Constructor with a Point class object reference parameter
	m_x = a.m_x;
	m_y = a.m_y;
}

Point::~Point() { //Our Destructor
	//std::cout << "This is the destructor!!" << std::endl;
}

//Our Get() Functions 
double Point::X() const {
	return m_x;
}

double Point::Y() const {
	return m_y;
}


//Our Set() Functions
void Point::X(const double& a) {
	m_x = a;
}

void Point::Y(const double& b) {
	m_y = b;
}

//ToString() Function; This function describes the Point class object that uses the . opeartor on the function at that moment in time
std::string Point::ToString() const {
	std::stringstream a;
	std::stringstream b;
	a << m_x;
	b << m_y;
	std::string resi = "Point {" + a.str() + "," + b.str() + "}";
	return resi;
}


//Distance() Functions. These functions calculate the distance between the Point class object to the origin and between 2 Point class objects respectively
double Point::Distance() const {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(const Point& p) const {
	return sqrt(pow(m_x - p.m_x, 2) + pow(m_y - p.m_y, 2));
}