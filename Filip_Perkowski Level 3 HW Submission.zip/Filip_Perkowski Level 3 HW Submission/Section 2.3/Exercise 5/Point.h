#pragma once

#ifndef Point_h
#define Point_h

#include <iostream>
#include <sstream>
#include <string>

//Objective -> This is our Point header file where we denotes all the components within the Point class


class Point {
	private:
		double m_x;
		double m_y;
	public:
		Point();
		Point(double a, double b);
		Point(const Point& a);
		~Point();

		//For overloaded functions aka functions with the same name its important for the parameters to be different. Otherwise, the compiler can't differentiate/determine which function we are calling
		//Our Get() Functions
		double X() const;
		double Y() const;

		//Our Set() Functions
		void X(const double& a);
		void Y(const double& b);

		//ToString() Function
		std::string ToString() const;

		//Distance() Functions
		double Distance() const;
		double Distance(const Point& p) const;



};

#endif