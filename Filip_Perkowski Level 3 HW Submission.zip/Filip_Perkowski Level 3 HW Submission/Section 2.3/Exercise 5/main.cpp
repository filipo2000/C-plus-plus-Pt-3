#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Line.h" //We are including the Line header file. The Line header file include the Point header file so there's no need for us to write a include directive to include the Point header file

//Objective -> This program is our main.cpp here we have our main function and we test and check the validity of all the components of the Point Class


int main() {

	Line l1; //Constructing a Line object. This initiates the default constrcutor
	//The below print line tests the default constructor
	std::cout << l1.P1().X() << "," << l1.P1().Y() << "," << l1.P2().X() << "," << l1.P2().Y(); //l1.P1() returns us the start Point class object contained within the Line class object. From this start point we choose to fetch the m_x aka X cordinate via the X() function
	//The above line return 0's for all the respective cordinates and it should

	Point p1; //Creates a Point class object aka memory is allocated. Default constructor is initiated
	Point p2(4, 10); //Constructor in the Point class which has 2 double parameters is initiatied
	Line l2(p1,p2); //We we create a Line class object. We furthermore invoke the constructor in the Line class which contains 2 Point class object parameters
	//Tetsing the constructor which take in 2 Point class type objects
	std::cout << l2.P1().X() << "," << l2.P1().Y() << "," << l2.P2().X() << "," << l2.P2().Y() << std::endl; //Here we are also simultaneously testing the Get() Functions; P1() and P2()

	Line l3(l2); //This create a Line object l3. In addition, the copy constructor is initiated
	//Testing the Copy Constructor
	std::cout << l3.P1().X() << "," << l3.P1().Y() << "," << l3.P2().X() << "," << l3.P2().Y() << std::endl;

	//The Deconstructor is initiated when the program is terminated. More specifically, when objects of Line class type get destroyed. Number of Line class type objects destroyed = Number of times the deconstructor gets called

	Line l4;
	Line l5;

	//Testing the Set() Functions()
	l1.P1(p2); //Based on the fact that we provided a point parameter we the compiler know that we are reffering to the Set() which sets Point start and it's m_x and m_y(aka x and y coordinates) for l1 which is an object of Line class type
	//Testing the set() function
	std::cout << l1.P1().X() << "," << l1.P1().Y() << std::endl;

	//Similar idea but now testing P2()
	l2.P2(p1); //This line should set it up so that Line object's l2 end Point is (0,0)
	//Print statement to check if it works
	std::cout << l2.P2().X() << "," << l2.P2().Y() << std::endl;

	//Testing our ToString() Function
	std::cout << l3.ToString() << std::endl;

	//Testing our Length() Function
	std::cout << l4.Length() << std::endl;

}