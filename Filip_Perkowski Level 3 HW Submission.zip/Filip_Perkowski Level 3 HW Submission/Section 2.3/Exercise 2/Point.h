#pragma once
#include <iostream>
#include <sstream>
#include <string>

#ifndef Point_h
#define Point_h

//Objective -> This is our header file which includes all the properties of our Point Class

//Call By Value - The value of the argument gets copied to the parameter. A copy of the argument gets made. The argument itself is in memory in additon to the copy made to intialize the parameter
//Call By Reference - Parameter is simply an alias aka another name for the arguement passes Ex: int& a= b; Here a is simply another name for b; We only have one variable here and that's b. a itself is not an independent variable but just a synonym/another name for variable b


class Point {
	private:
		double m_x; //These are our 2 properties of the Point class object
		double m_y;
	public:
		//Our Set Of Constructors
		Point(); //Default Constructor
		Point(double y, double z); //Constructor that take 2 double arguments
		Point(Point& z); //Copy Constructor
		~Point(); //Deconstructor

		//Our Get Functions(); Both fetch the m_x and m_y fields
		double GetX();
		double GetY();

		//Our Set Functions(); Set the m_x and m_y fields
		void SetX(double a);
		void SetY(double b);

		//To String Function() which returns a string that describes the Point object
		std::string ToString();

		//Our Distance() Functions
		double DistanceOrigin(); //Function returns the distance between a Point class object and the origin
		double Distance(const Point& a); //This function returns the distance between 2 point objects. Now by making the Parameter a reference to a Point we will now have a Call by Reference rather than a call by value if we decide to call this function using the . operator



};

#endif