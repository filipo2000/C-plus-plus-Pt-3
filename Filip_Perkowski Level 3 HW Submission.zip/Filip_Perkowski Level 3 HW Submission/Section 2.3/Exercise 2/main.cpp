#include <iostream>
#include <sstream>
#include <cmath>
#include "Point.h"

//Objective -> This is our main.cpp file. In this file we have our main() function and we test the Point class 

int main() {

	Point p1; //Default Constructor is called to constructor this Point object
	Point p2(20, 30); //Constructor with 2 double arguments is called; We didn't implement a cout/print statement within the body of this constructor variant
	Point p3(p2); //Copy constructor is called

	std::cout << "The Distance between points p1 and p2 is: " << p1.Distance(p2) << std::endl;

	//We get a compiler error when trying to change the input point. This is because the parameter of the Distance() function is a [const] reference

}

