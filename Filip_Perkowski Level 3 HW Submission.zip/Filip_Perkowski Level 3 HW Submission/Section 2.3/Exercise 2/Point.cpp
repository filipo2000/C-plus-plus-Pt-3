#include <iostream>
#include <sstream>
#include <cmath>
#include "Point.h"

//Objective -> This is our /ccp file which defines all the elements(functions etc.) of the Point Class


//Our Set of Constructors Defined

Point::Point() { //Our Default Constructor
	m_x = 0;
	m_y = 0;
	std::cout << "The Default Constructor" << std::endl;
}

Point::Point(double a, double b) { //Constructor that takes 2 double parameters
	m_x = a;
	m_y = b;
}

Point::Point(Point& y) { //Our Copy Constructor
	m_x = y.m_x;
	m_y = y.m_y;
	std::cout << "The Copy Constructor" << std::endl;
}

Point::~Point() { //Our Destructor
	std::cout << "The Destructor" << std::endl;
}

//Our Get() Functions Defined
double Point::GetX() {
	return m_x;
}


double Point::GetY() {
	return m_y;
}


//Our Set() Functions Defined

void Point::SetX(double a) {
	m_x = a;
}

void Point::SetY(double b) {
	m_y = b;
}


//Our ToString() Function
std::string Point::ToString() {
	std::stringstream a , b;
	a << m_x;
	b << m_y;
	std::string resi = "Point {" + a.str() + "," + b.str() + "}";
	return resi;
}


//Our Distance() Functions

double Point::DistanceOrigin() {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(const Point& o) { //Our Distance function now has a const reference parameter()
	return sqrt(pow(m_x - o.m_x, 2) + pow(m_y - o.m_y, 2));
}
